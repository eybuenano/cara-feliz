ocvP5
=====

a simple OpenCV wrapper for Processing
